# Backend CRM - Listo para Hostinger 
 
1. Sube todos estos archivos a tu hosting 
2. Conecta por SSH 
3. Ejecuta: bash deploy-hostinger.sh 
4. Verifica: pm2 status 
 
Mas informacion en DEPLOYMENT.md 
